# Codeforces Problem Tracker - Chrome Extension
-----------------------------------------------------------------------------------------------------
This chrome extension helps you to track your codeforces problems and classify them as :
1. Understood but not implemented (color yellow)
2. Understood and implemented (color green)